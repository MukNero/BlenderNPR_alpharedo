@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
  echo Usage: run_all_windows.bat ^<path-to-blender.exe^> [output-dir]
  exit /b 2
)

set "BLENDER=%~f1"
if not exist "%BLENDER%" (
  echo Blender not found: %BLENDER%
  exit /b 2
)

if "%~2"=="" (
  set "OUT=%~dp0output"
) else (
  set "OUT=%~f2"
)
if not exist "%OUT%" mkdir "%OUT%"

set "SUITE=%~dp0"
set "FAILED=0"

call :run state "%BLENDER%" --factory-startup -b --python "%SUITE%01_alpha_state_strict.py" -- "%OUT%\alpha_state_result.json"
call :run persistence_create "%BLENDER%" --factory-startup -b --python "%SUITE%02_create_persistence.py" -- "%OUT%"
if exist "%OUT%\alpha_persistence.blend" (
  call :run persistence_verify "%BLENDER%" "%OUT%\alpha_persistence.blend" -b --python "%SUITE%03_verify_persistence.py" -- "%OUT%\alpha_persistence_expected.json" "%OUT%\alpha_persistence_actual.json"
) else (
  echo Missing persistence fixture>>"%OUT%\summary.log"
  set "FAILED=1"
)
call :run surface_visual "%BLENDER%" --factory-startup -b --python "%SUITE%04_surface_visual_strict.py" -- "%OUT%"
call :run shadow_visual "%BLENDER%" --factory-startup -b --python "%SUITE%05_shadow_visual_strict.py" -- "%OUT%"
call :run state_fuzz "%BLENDER%" --factory-startup -b --python "%SUITE%07_state_fuzz_strict.py" -- "%OUT%\state_fuzz.json"

if "%FAILED%"=="0" (
  echo STRICT_PASS: all automated Alpha tests passed.
  echo STRICT_PASS: all automated Alpha tests passed.>"%OUT%\FINAL_PASS.txt"
  exit /b 0
) else (
  echo STRICT_FAIL: one or more Alpha tests failed. Inspect %OUT%\*.log
  exit /b 1
)

:run
set "NAME=%~1"
shift
set "LOG=%OUT%\%NAME%.log"
echo ==== %NAME% ==== > "%LOG%"
%* >> "%LOG%" 2>&1
set "RC=!ERRORLEVEL!"
type "%LOG%"
findstr /C:"STRICT_PASS:" "%LOG%" >nul
if errorlevel 1 (
  echo [%NAME%] missing STRICT_PASS marker, process RC=!RC!
  set "FAILED=1"
) else if not "!RC!"=="0" (
  echo [%NAME%] non-zero process RC=!RC!
  set "FAILED=1"
) else (
  echo [%NAME%] PASS
)
exit /b 0
