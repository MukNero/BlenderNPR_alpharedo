from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
from common import args_after_doubledash, guarded, strict_fail, strict_pass, write_json


def main() -> None:
    args = args_after_doubledash()
    out_json = Path(args[0]) if args else Path.cwd() / "alpha_state_result.json"

    errors: list[str] = []
    observations: dict = {
        "blender_version": bpy.app.version_string,
        "build_hash": bpy.app.build_hash.decode(errors="replace") if isinstance(bpy.app.build_hash, bytes) else str(bpy.app.build_hash),
        "build_branch": bpy.app.build_branch.decode(errors="replace") if isinstance(bpy.app.build_branch, bytes) else str(bpy.app.build_branch),
        "surface": [],
        "shadow": [],
        "transitions": [],
    }

    expected_surface = {
        "OPAQUE": "DITHERED",
        "CLIP": "DITHERED",
        "HASHED": "DITHERED",
        "BLEND": "BLENDED",
    }

    mat = bpy.data.materials.new("HCQ_Alpha_State_Strict")
    mat.use_nodes = True

    for mode, expected_render_method in expected_surface.items():
        mat.blend_method = mode
        row = {
            "set": mode,
            "blend_method": mat.blend_method,
            "surface_render_method": mat.surface_render_method,
        }
        observations["surface"].append(row)
        if row["blend_method"] != mode:
            errors.append(f"surface {mode}: read back {row['blend_method']}")
        if row["surface_render_method"] != expected_render_method:
            errors.append(
                f"surface {mode}: render method {row['surface_render_method']}, expected {expected_render_method}"
            )

    if not hasattr(mat, "shadow_method"):
        errors.append("Material.shadow_method is missing")
    else:
        expected_transparent = {"NONE": False, "OPAQUE": False, "CLIP": True, "HASHED": True}
        for mode in ("NONE", "OPAQUE", "CLIP", "HASHED"):
            mat.shadow_method = mode
            row = {
                "set": mode,
                "shadow_method": mat.shadow_method,
                "use_transparent_shadow": bool(mat.use_transparent_shadow),
            }
            observations["shadow"].append(row)
            if row["shadow_method"] != mode:
                errors.append(f"shadow {mode}: read back {row['shadow_method']}")
            if row["use_transparent_shadow"] != expected_transparent[mode]:
                errors.append(
                    f"shadow {mode}: use_transparent_shadow={row['use_transparent_shadow']}, "
                    f"expected {expected_transparent[mode]}"
                )

    # Transition regression: surface_render_method must not collapse OPAQUE/CLIP/HASHED
    # unless explicitly switched through the coarse render-method API.
    for start in ("OPAQUE", "CLIP", "HASHED"):
        mat.blend_method = start
        before = mat.blend_method
        mat.surface_render_method = "DITHERED"
        after = mat.blend_method
        observations["transitions"].append({"start": start, "after_dithered": after})
        if before != start or after != start:
            errors.append(f"DITHERED transition collapsed {start} to {after}")

    mat.blend_method = "BLEND"
    mat.surface_render_method = "DITHERED"
    observations["transitions"].append({"start": "BLEND", "after_dithered": mat.blend_method})
    if mat.blend_method != "HASHED":
        errors.append(f"BLEND -> DITHERED expected HASHED fallback, got {mat.blend_method}")

    mat.blend_method = "CLIP"
    for value in (0.0, 0.00001, 0.12345, 0.5, 0.99999, 1.0):
        mat.alpha_threshold = value
        if abs(mat.alpha_threshold - value) > 1e-6:
            errors.append(f"alpha_threshold {value} read back {mat.alpha_threshold}")

    observations["errors"] = errors
    write_json(out_json, observations)

    if errors:
        strict_fail("; ".join(errors))
    strict_pass("API state, transitions and shadow compatibility passed")


guarded(main)
