from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
from mathutils import Vector
from statistics import mean
from common import args_after_doubledash, guarded, look_at, set_eevee, strict_fail, strict_pass, write_json

WIDTH = 960
HEIGHT = 480
ORTHO_SCALE = 9.0
ASPECT = WIDTH / HEIGHT


def mat_emission(name, color):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs[0].default_value = (*color, 1.0)
    em.inputs[1].default_value = 1.0
    nt.links.new(em.outputs[0], out.inputs[0])
    return mat


def mat_alpha(name, mode, color, opacity, threshold=0.5):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.blend_method = mode
    if hasattr(mat, "shadow_method"):
        mat.shadow_method = "OPAQUE"
    mat.alpha_threshold = threshold
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    transparent = nt.nodes.new("ShaderNodeBsdfTransparent")
    emission = nt.nodes.new("ShaderNodeEmission")
    emission.inputs[0].default_value = (*color, 1.0)
    emission.inputs[1].default_value = 1.0
    mix = nt.nodes.new("ShaderNodeMixShader")
    mix.inputs[0].default_value = opacity
    nt.links.new(transparent.outputs[0], mix.inputs[1])
    nt.links.new(emission.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs[0])
    return mat


def add_plane(name, x, z, size, mat, y=0.0):
    bpy.ops.mesh.primitive_plane_add(size=size, location=(x, y, z), rotation=(1.57079632679, 0, 0))
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    return obj


def px_from_world(scene, camera, x, z):
    from bpy_extras.object_utils import world_to_camera_view
    co = world_to_camera_view(scene, camera, Vector((x, 0.0, z)))
    px = int(round(co.x * (WIDTH - 1)))
    py = int(round(co.y * (HEIGHT - 1)))
    return px, py


def region_mean(pixels, px, py, radius=18):
    vals = []
    for y in range(max(0, py - radius), min(HEIGHT, py + radius + 1)):
        for x in range(max(0, px - radius), min(WIDTH, px + radius + 1)):
            i = (y * WIDTH + x) * 4
            vals.append((pixels[i], pixels[i + 1], pixels[i + 2]))
    return tuple(mean(v[c] for v in vals) for c in range(3))


def projection_t(bg, fg, sample):
    d = tuple(fg[i] - bg[i] for i in range(3))
    denom = sum(v * v for v in d)
    if denom < 1e-12:
        return 0.0
    return sum((sample[i] - bg[i]) * d[i] for i in range(3)) / denom


def dist(a, b):
    return sum((a[i] - b[i]) ** 2 for i in range(3)) ** 0.5


def main():
    args = args_after_doubledash()
    out_dir = Path(args[0]) if args else Path.cwd()
    out_dir.mkdir(parents=True, exist_ok=True)
    png = out_dir / "surface_visual.png"
    blend = out_dir / "surface_visual.blend"
    report = out_dir / "surface_visual_metrics.json"

    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    engine = set_eevee(scene)
    scene.render.resolution_x = WIDTH
    scene.render.resolution_y = HEIGHT
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.filepath = str(png)
    scene.render.film_transparent = False
    try:
        scene.view_settings.look = "AgX - Medium High Contrast"
    except Exception:
        pass

    world = scene.world or bpy.data.worlds.new("World")
    scene.world = world
    world.use_nodes = True
    bg_node = world.node_tree.nodes.get("Background")
    bg_node.inputs[0].default_value = (0.015, 0.02, 0.03, 1.0)
    bg_node.inputs[1].default_value = 0.0

    bg_color = (0.04, 0.07, 0.12)
    fg_color = (1.0, 0.18, 0.04)
    add_plane("Backdrop", 0, 0, 20, mat_emission("BackdropMat", bg_color), y=0.6)

    modes = ("OPAQUE", "CLIP", "HASHED", "BLEND")
    xs = (-3.3, -1.1, 1.1, 3.3)
    for x, mode in zip(xs, modes):
        add_plane(
            f"MODE_{mode}",
            x,
            1.0,
            1.55,
            mat_alpha(f"MAT_{mode}", mode, fg_color, 0.35, 0.5),
            y=0.0,
        )

    # Same node graph, same opacity, different CLIP thresholds. This catches shader-cache key bugs.
    for x, threshold in zip((-2.2, 0.0, 2.2), (0.25, 0.50, 0.75)):
        add_plane(
            f"CLIP_T_{threshold:.2f}",
            x,
            -1.15,
            1.40,
            mat_alpha(f"MAT_CLIP_T_{threshold:.2f}", "CLIP", (0.1, 0.85, 0.22), 0.50, threshold),
            y=0.0,
        )

    bpy.ops.object.camera_add(location=(0, -10, 0))
    cam = bpy.context.object
    cam.data.type = "ORTHO"
    cam.data.ortho_scale = ORTHO_SCALE
    # Exact front view: camera local -Z points along world +Y, local +Y points world +Z.
    cam.rotation_euler = (1.57079632679, 0.0, 0.0)
    scene.camera = cam

    bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    bpy.ops.render.render(write_still=True)

    try:
        img = bpy.data.images.load(str(png), check_existing=False)
    except Exception as exc:
        strict_fail(f"Unable to reload rendered PNG: {exc}")
    if img is None or img.size[0] != WIDTH or img.size[1] != HEIGHT:
        strict_fail(f"Rendered image missing or unexpected size: {None if img is None else tuple(img.size)}")
    pixels = list(img.pixels)
    bg = region_mean(pixels, *px_from_world(scene, cam, 0.0, 0.0), radius=12)
    samples = {mode: region_mean(pixels, *px_from_world(scene, cam, x, 1.0)) for x, mode in zip(xs, modes)}
    clip_samples = {
        f"{th:.2f}": region_mean(pixels, *px_from_world(scene, cam, x, -1.15))
        for x, th in zip((-2.2, 0.0, 2.2), (0.25, 0.50, 0.75))
    }

    opaque = samples["OPAQUE"]
    tvals = {mode: projection_t(bg, opaque, rgb) for mode, rgb in samples.items()}
    clip_tvals = {k: projection_t(bg, clip_samples["0.25"], v) for k, v in clip_samples.items()}
    errors = []

    if dist(opaque, bg) < 0.15:
        errors.append(f"OPAQUE is not visibly opaque: distance={dist(opaque, bg):.4f}")
    if dist(samples["CLIP"], bg) > 0.08:
        errors.append(f"CLIP alpha 0.35 threshold 0.5 did not discard: distance={dist(samples['CLIP'], bg):.4f}")
    # Projection is measured after AgX and PNG color transforms, so it is deliberately not
    # numerically equal to the scene-linear opacity. Keep it bounded away from 0 and 1.
    if not (0.12 <= tvals["HASHED"] <= 0.75):
        errors.append(f"HASHED mean coverage unexpected: t={tvals['HASHED']:.4f}")
    if not (0.12 <= tvals["BLEND"] <= 0.75):
        errors.append(f"BLEND mean coverage unexpected: t={tvals['BLEND']:.4f}")
    if dist(clip_samples["0.25"], bg) < 0.15:
        errors.append("CLIP threshold 0.25 should keep opacity 0.50")
    if dist(clip_samples["0.50"], bg) < 0.15:
        errors.append("CLIP equality threshold 0.50 should keep opacity 0.50")
    if dist(clip_samples["0.75"], bg) > 0.08:
        errors.append("CLIP threshold 0.75 should discard opacity 0.50")

    write_json(
        report,
        {
            "engine": engine,
            "background": bg,
            "samples": samples,
            "projection_t": tvals,
            "clip_samples": clip_samples,
            "clip_projection_t": clip_tvals,
            "errors": errors,
        },
    )
    if errors:
        strict_fail("; ".join(errors))
    strict_pass("Surface modes, threshold branches and shader cache separation passed")


guarded(main)
