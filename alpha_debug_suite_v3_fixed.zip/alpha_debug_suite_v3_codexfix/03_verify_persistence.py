from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
import json
from common import args_after_doubledash, guarded, strict_fail, strict_pass, write_json


def main() -> None:
    args = args_after_doubledash()
    if len(args) < 2:
        strict_fail("Usage: <expected.json> <result.json>")
    expected_path = Path(args[0])
    result_path = Path(args[1])
    expected = json.loads(expected_path.read_text(encoding="utf-8"))
    errors = []
    actual = []
    for item in expected:
        mat = bpy.data.materials.get(item["name"])
        if mat is None:
            errors.append(f"missing material {item['name']}")
            continue
        row = {
            "name": mat.name,
            "blend_method": mat.blend_method,
            "shadow_method": getattr(mat, "shadow_method", None),
            "alpha_threshold": mat.alpha_threshold,
        }
        actual.append(row)
        if row["blend_method"] != item["blend_method"]:
            errors.append(f"{mat.name}: blend {row['blend_method']} != {item['blend_method']}")
        if row["shadow_method"] != item["shadow_method"]:
            errors.append(f"{mat.name}: shadow {row['shadow_method']} != {item['shadow_method']}")
        if abs(row["alpha_threshold"] - item["alpha_threshold"]) > 1e-5:
            errors.append(f"{mat.name}: threshold {row['alpha_threshold']} != {item['alpha_threshold']}")

    write_json(result_path, {"actual": actual, "errors": errors})
    if errors:
        strict_fail("; ".join(errors))
    strict_pass("Save/reload persistence passed")


guarded(main)
