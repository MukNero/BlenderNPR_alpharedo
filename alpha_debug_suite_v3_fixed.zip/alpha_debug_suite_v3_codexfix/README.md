# Blender 5.2 NPR Goo Alpha — Strict Debug Suite v3.1

This suite validates the patched Windows build at the RNA, save/reload, EEVEE surface,
shadow, shader-cache and stress levels.

Blender may return process exit code `0` after a Python exception. These tests therefore:

- print an explicit `STRICT_PASS:` marker;
- terminate failures with `os._exit(nonzero)`;
- write JSON metrics and rendered evidence where applicable.

## Core run

```bat
run_all_windows.bat "D:\path\to\blender.exe" "D:\AlphaDebugOutput"
```

Core coverage:

1. `OPAQUE / CLIP / HASHED / BLEND` RNA round-trip;
2. `NONE / OPAQUE / CLIP / HASHED` shadow state;
3. coarse render-method transitions;
4. alpha-threshold precision;
5. save, close, reopen and verify 16 surface/shadow combinations;
6. EEVEE surface render with automated pixel checks;
7. clip thresholds 0.25 / 0.50 / 0.75 and shader-cache separation;
8. shadow behavior with automated luminance checks;
9. 1,000+ randomized state transitions and material-copy checks.

A successful run creates `FINAL_PASS.txt`. Do not accept a run based only on Blender's
process exit code.

Expected evidence includes:

- `alpha_state_result.json`
- `alpha_persistence.blend`
- `alpha_persistence_actual.json`
- `surface_visual.png`
- `surface_visual_metrics.json`
- `shadow_visual.png`
- `shadow_visual_metrics.json`
- `state_fuzz.json`
- per-test logs
- `FINAL_PASS.txt`

## Shader compile/render stress

Run after the core suite passes:

```bat
run_stress_windows.bat "D:\path\to\blender.exe" "D:\AlphaStressOutput"
```

This creates and renders 80 material variants spanning all surface modes, all shadow modes,
five clip thresholds and five opacity values. It is intended to reveal shader compilation,
cache-key, crash and packaging problems.

## Real project audit

Use only a copied `.blend` file:

```bat
run_material_audit_windows.bat "D:\path\to\blender.exe" "D:\copy\project_test.blend"
```

The audit is read-only and does not call save.

## Corrected defects in the earlier test package

- The old visual script wrote `floor.use_nodes` instead of `floor_mat.use_nodes`.
- Unused persistence materials were not marked `use_fake_user`, so they disappeared on save.
- The original tests could appear successful when Blender swallowed a Python exception and exited 0.
- The original shadow fixture framed sample points outside the camera.

These issues are corrected in v3.1.
