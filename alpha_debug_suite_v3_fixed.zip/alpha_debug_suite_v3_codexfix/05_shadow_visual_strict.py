from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
from mathutils import Vector
from statistics import mean
from common import args_after_doubledash, guarded, set_eevee, strict_fail, strict_pass, write_json

WIDTH = 960
HEIGHT = 360


def make_floor():
    mat = bpy.data.materials.new("FloorMat")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs[0].default_value = (0.72, 0.72, 0.72, 1.0)
    bsdf.inputs[2].default_value = 0.95
    bpy.ops.mesh.primitive_plane_add(size=20, location=(0, 0, 0))
    floor = bpy.context.object
    floor.name = "Floor"
    floor.data.materials.append(mat)
    return floor


def make_caster(name, x, shadow_mode):
    mat = bpy.data.materials.new(name + "_Mat")
    mat.use_nodes = True
    mat.blend_method = "HASHED"
    missing_shadow_api = not hasattr(mat, "shadow_method")
    if not missing_shadow_api:
        mat.shadow_method = shadow_mode
    else:
        mat.use_transparent_shadow = shadow_mode in {"CLIP", "HASHED"}
    mat.alpha_threshold = 0.5
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    trans = nt.nodes.new("ShaderNodeBsdfTransparent")
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs[0].default_value = (0.08, 0.25, 0.9, 1.0)
    mix = nt.nodes.new("ShaderNodeMixShader")
    # 35% opaque coverage.
    mix.inputs[0].default_value = 0.35
    nt.links.new(trans.outputs[0], mix.inputs[1])
    nt.links.new(bsdf.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs[0])
    bpy.ops.mesh.primitive_plane_add(size=1.5, location=(x, 0, 2.0))
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    if hasattr(obj, "visible_camera"):
        obj.visible_camera = False
    return obj, missing_shadow_api


def sample_world(scene, camera, pixels, x, y, radius=18):
    from bpy_extras.object_utils import world_to_camera_view
    co = world_to_camera_view(scene, camera, Vector((x, y, 0.0)))
    px = int(round(co.x * (WIDTH - 1)))
    py = int(round(co.y * (HEIGHT - 1)))
    vals = []
    for yy in range(max(0, py - radius), min(HEIGHT, py + radius + 1)):
        for xx in range(max(0, px - radius), min(WIDTH, px + radius + 1)):
            i = (yy * WIDTH + xx) * 4
            vals.append((pixels[i], pixels[i + 1], pixels[i + 2]))
    if not vals:
        strict_fail(f"Empty sample region at world ({x}, {y}) -> ({px}, {py})")
    rgb = tuple(mean(v[c] for v in vals) for c in range(3))
    lum = 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]
    return rgb, lum


def main():
    args = args_after_doubledash()
    out_dir = Path(args[0]) if args else Path.cwd()
    out_dir.mkdir(parents=True, exist_ok=True)
    png = out_dir / "shadow_visual.png"
    blend = out_dir / "shadow_visual.blend"
    report = out_dir / "shadow_visual_metrics.json"

    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    engine = set_eevee(scene)
    scene.render.resolution_x = WIDTH
    scene.render.resolution_y = HEIGHT
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.filepath = str(png)
    scene.render.film_transparent = False

    world = scene.world or bpy.data.worlds.new("World")
    scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    bg.inputs[0].default_value = (0.02, 0.025, 0.035, 1.0)
    bg.inputs[1].default_value = 0.08

    make_floor()
    xs = (-3.6, -1.2, 1.2, 3.6)
    modes = ("NONE", "OPAQUE", "CLIP", "HASHED")
    missing_shadow_api = False
    for x, mode in zip(xs, modes):
        _, missing = make_caster(f"SHADOW_{mode}", x, mode)
        missing_shadow_api |= missing

    bpy.ops.object.light_add(type="SUN", location=(0, 0, 6.0))
    sun = bpy.context.object
    sun.data.energy = 4.0
    sun.data.angle = 0.03
    sun.rotation_euler = (0.0, 0.0, 0.0)

    bpy.ops.object.camera_add(location=(0, 0, 10.0))
    cam = bpy.context.object
    cam.data.type = "ORTHO"
    cam.data.ortho_scale = 10.0
    cam.rotation_euler = (0.0, 0.0, 0.0)
    scene.camera = cam

    bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    bpy.ops.render.render(write_still=True)
    if not png.exists() or png.stat().st_size < 1000:
        strict_fail("Shadow render was not produced")

    img = bpy.data.images.load(str(png), check_existing=False)
    pixels = list(img.pixels)
    ref_rgb, ref_lum = sample_world(scene, cam, pixels, 0.0, 1.45)
    samples = {}
    for x, mode in zip(xs, modes):
        rgb, lum = sample_world(scene, cam, pixels, x, 0.0)
        samples[mode] = {"rgb": rgb, "luminance": lum, "drop": ref_lum - lum}

    errors = []
    if missing_shadow_api:
        errors.append("Material.shadow_method API is missing")
    if abs(samples["NONE"]["drop"]) > 0.07:
        errors.append(f"NONE unexpectedly casts shadow: drop={samples['NONE']['drop']:.4f}")
    if samples["OPAQUE"]["drop"] < 0.12:
        errors.append(f"OPAQUE shadow too weak/missing: drop={samples['OPAQUE']['drop']:.4f}")
    if abs(samples["CLIP"]["drop"]) > 0.07:
        errors.append(f"CLIP opacity .35 threshold .5 should not shadow: drop={samples['CLIP']['drop']:.4f}")
    hashed_drop = samples["HASHED"]["drop"]
    opaque_drop = samples["OPAQUE"]["drop"]
    if not (0.03 < hashed_drop < max(0.04, opaque_drop - 0.03)):
        errors.append(
            f"HASHED shadow should be partial: hashed_drop={hashed_drop:.4f}, opaque_drop={opaque_drop:.4f}"
        )

    write_json(
        report,
        {
            "engine": engine,
            "reference": {"rgb": ref_rgb, "luminance": ref_lum},
            "samples": samples,
            "missing_shadow_api": missing_shadow_api,
            "errors": errors,
        },
    )
    if errors:
        strict_fail("; ".join(errors))
    strict_pass("Shadow NONE/OPAQUE/CLIP/HASHED behavior passed")


guarded(main)
