from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
from common import args_after_doubledash, guarded, set_eevee, strict_fail, strict_pass, write_json


def make_material(name, surface, shadow, threshold, opacity):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.blend_method = surface
    if not hasattr(mat, "shadow_method"):
        strict_fail("Material.shadow_method is missing")
    mat.shadow_method = shadow
    mat.alpha_threshold = threshold
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    trans = nt.nodes.new("ShaderNodeBsdfTransparent")
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs[0].default_value = (0.08 + opacity * 0.8, 0.2, 0.85 - opacity * 0.5, 1.0)
    bsdf.inputs[2].default_value = 0.8
    mix = nt.nodes.new("ShaderNodeMixShader")
    mix.inputs[0].default_value = opacity
    nt.links.new(trans.outputs[0], mix.inputs[1])
    nt.links.new(bsdf.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs[0])
    return mat


def main():
    args = args_after_doubledash()
    out_dir = Path(args[0]) if args else Path.cwd()
    out_dir.mkdir(parents=True, exist_ok=True)
    png = out_dir / "shader_compile_stress.png"
    blend = out_dir / "shader_compile_stress.blend"
    report = out_dir / "shader_compile_stress.json"

    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    engine = set_eevee(scene)
    scene.render.resolution_x = 768
    scene.render.resolution_y = 768
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.filepath = str(png)

    world = scene.world or bpy.data.worlds.new("World")
    scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    bg.inputs[0].default_value = (0.035, 0.04, 0.055, 1.0)
    bg.inputs[1].default_value = 0.25

    # Ground catches all four shadow paths.
    bpy.ops.mesh.primitive_plane_add(size=24, location=(0, 0, 0))
    floor = bpy.context.object
    floor_mat = bpy.data.materials.new("StressFloor")
    floor_mat.use_nodes = True
    floor.data.materials.append(floor_mat)

    surfaces = ("OPAQUE", "CLIP", "HASHED", "BLEND")
    shadows = ("NONE", "OPAQUE", "CLIP", "HASHED")
    thresholds = (0.0, 0.25, 0.5, 0.75, 1.0)
    opacities = (0.05, 0.2, 0.5, 0.8, 0.95)
    rows = []
    index = 0
    for s_i, surface in enumerate(surfaces):
        for sh_i, shadow in enumerate(shadows):
            for t_i, threshold in enumerate(thresholds):
                opacity = opacities[(s_i + sh_i + t_i) % len(opacities)]
                x = -8.0 + (index % 10) * 1.78
                y = -6.5 + (index // 10) * 1.75
                bpy.ops.mesh.primitive_cube_add(size=1.1, location=(x, y, 0.9))
                obj = bpy.context.object
                mat = make_material(
                    f"STRESS_{surface}_{shadow}_{threshold:.2f}_{index:03d}",
                    surface, shadow, threshold, opacity,
                )
                obj.data.materials.append(mat)
                rows.append({"name": mat.name, "surface": surface, "shadow": shadow,
                             "threshold": threshold, "opacity": opacity})
                index += 1

    bpy.ops.object.light_add(type="SUN", location=(0, 0, 10))
    sun = bpy.context.object
    sun.rotation_euler = (0.45, -0.35, 0.25)
    sun.data.energy = 3.0
    sun.data.angle = 0.05

    bpy.ops.object.camera_add(location=(0, -22, 20))
    cam = bpy.context.object
    cam.rotation_euler = ((0.0, 0.0, 0.0))
    from mathutils import Vector
    cam.rotation_euler = (Vector((0, 0, 1.5)) - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.type = "ORTHO"
    cam.data.ortho_scale = 21.0
    scene.camera = cam

    bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    bpy.ops.render.render(write_still=True)
    if not png.exists() or png.stat().st_size < 10000:
        strict_fail("Stress render missing or unexpectedly small")

    write_json(report, {
        "engine": engine,
        "material_count": len(rows),
        "image_bytes": png.stat().st_size,
        "materials": rows,
    })
    strict_pass(f"Compiled and rendered {len(rows)} alpha/shadow shader variants")


guarded(main)
