from __future__ import annotations

from pathlib import Path
import random
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
from common import args_after_doubledash, guarded, strict_fail, strict_pass, write_json


def main() -> None:
    args = args_after_doubledash()
    out_json = Path(args[0]) if args else Path.cwd() / "alpha_state_fuzz.json"
    rng = random.Random(0xA17A)
    surface_modes = ("OPAQUE", "CLIP", "HASHED", "BLEND")
    shadow_modes = ("NONE", "OPAQUE", "CLIP", "HASHED")
    expected_render = {"OPAQUE": "DITHERED", "CLIP": "DITHERED", "HASHED": "DITHERED", "BLEND": "BLENDED"}
    expected_transparent_shadow = {"NONE": False, "OPAQUE": False, "CLIP": True, "HASHED": True}
    errors = []
    checks = 0

    # Dynamically registered RNA properties are present in bl_rna and on instances, not
    # necessarily as Python descriptors on bpy.types.Material itself.
    if bpy.types.Material.bl_rna.properties.get("shadow_method") is None:
        strict_fail("Material.shadow_method is missing")

    materials = []
    for i in range(64):
        mat = bpy.data.materials.new(f"FUZZ_{i:03d}")
        mat.use_nodes = True
        materials.append(mat)

    for step in range(1024):
        mat = rng.choice(materials)
        operation = rng.randrange(6)
        if operation == 0:
            mode = rng.choice(surface_modes)
            mat.blend_method = mode
            checks += 2
            if mat.blend_method != mode:
                errors.append(f"step {step}: blend set {mode}, got {mat.blend_method}")
            if mat.surface_render_method != expected_render[mode]:
                errors.append(f"step {step}: {mode} render={mat.surface_render_method}")
        elif operation == 1:
            mode = rng.choice(shadow_modes)
            mat.shadow_method = mode
            checks += 2
            if mat.shadow_method != mode:
                errors.append(f"step {step}: shadow set {mode}, got {mat.shadow_method}")
            if bool(mat.use_transparent_shadow) != expected_transparent_shadow[mode]:
                errors.append(f"step {step}: shadow {mode} transparent flag mismatch")
        elif operation == 2:
            value = rng.random()
            mat.alpha_threshold = value
            checks += 1
            if abs(mat.alpha_threshold - value) > 2e-6:
                errors.append(f"step {step}: threshold {value} -> {mat.alpha_threshold}")
        elif operation == 3:
            # The coarse API must preserve OPAQUE/CLIP/HASHED when already deferred.
            start = rng.choice(("OPAQUE", "CLIP", "HASHED"))
            mat.blend_method = start
            mat.surface_render_method = "DITHERED"
            checks += 1
            if mat.blend_method != start:
                errors.append(f"step {step}: DITHERED collapsed {start} -> {mat.blend_method}")
        elif operation == 4:
            mat.blend_method = "BLEND"
            mat.surface_render_method = "DITHERED"
            checks += 1
            if mat.blend_method != "HASHED":
                errors.append(f"step {step}: BLEND->DITHERED got {mat.blend_method}")
        else:
            value = bool(rng.getrandbits(1))
            mat.use_transparent_shadow = value
            checks += 2
            expected = "HASHED" if value else "OPAQUE"
            if bool(mat.use_transparent_shadow) != value:
                errors.append(f"step {step}: transparent shadow bool failed")
            if mat.shadow_method != expected:
                errors.append(f"step {step}: transparent shadow {value} gave {mat.shadow_method}, expected {expected}")

        if len(errors) >= 50:
            break

    # Copying a material must preserve all four state fields.
    source = materials[0]
    for surface in surface_modes:
        for shadow in shadow_modes:
            source.blend_method = surface
            source.shadow_method = shadow
            source.alpha_threshold = 0.123456
            copy = source.copy()
            checks += 4
            if copy.blend_method != surface:
                errors.append(f"copy: {surface} -> {copy.blend_method}")
            if copy.shadow_method != shadow:
                errors.append(f"copy shadow: {shadow} -> {copy.shadow_method}")
            if abs(copy.alpha_threshold - 0.123456) > 2e-6:
                errors.append(f"copy threshold: {copy.alpha_threshold}")
            if copy.surface_render_method != expected_render[surface]:
                errors.append(f"copy render: {surface} -> {copy.surface_render_method}")
            bpy.data.materials.remove(copy)

    write_json(out_json, {"checks": checks, "errors": errors})
    if errors:
        strict_fail("; ".join(errors[:20]))
    strict_pass(f"RNA state fuzz passed ({checks} checks)")


guarded(main)
