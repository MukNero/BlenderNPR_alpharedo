@echo off
setlocal EnableExtensions
if "%~1"=="" (
  echo Usage: run_stress_windows.bat ^<path-to-blender.exe^> [output-dir]
  exit /b 2
)
set "BLENDER=%~f1"
if "%~2"=="" (set "OUT=%~dp0stress_output") else (set "OUT=%~f2")
if not exist "%OUT%" mkdir "%OUT%"
"%BLENDER%" --factory-startup -b --python "%~dp007_state_fuzz_strict.py" -- "%OUT%\state_fuzz.json" > "%OUT%\state_fuzz.log" 2>&1
set "RC1=%ERRORLEVEL%"
type "%OUT%\state_fuzz.log"
"%BLENDER%" --factory-startup -b --python "%~dp008_shader_compile_stress.py" -- "%OUT%" > "%OUT%\shader_stress.log" 2>&1
set "RC2=%ERRORLEVEL%"
type "%OUT%\shader_stress.log"
findstr /C:"STRICT_PASS:" "%OUT%\state_fuzz.log" >nul || exit /b 1
findstr /C:"STRICT_PASS:" "%OUT%\shader_stress.log" >nul || exit /b 1
if not "%RC1%"=="0" exit /b 1
if not "%RC2%"=="0" exit /b 1
echo STRICT_PASS: stress suite passed.
exit /b 0
