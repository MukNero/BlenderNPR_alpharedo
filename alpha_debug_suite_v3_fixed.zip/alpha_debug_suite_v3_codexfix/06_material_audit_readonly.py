from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
from common import args_after_doubledash, guarded, strict_pass, write_json


def main():
    args = args_after_doubledash()
    out_json = Path(args[0]) if args else Path.cwd() / "material_audit.json"
    rows = []
    for mat in bpy.data.materials:
        rows.append(
            {
                "name": mat.name,
                "blend_method": getattr(mat, "blend_method", None),
                "surface_render_method": getattr(mat, "surface_render_method", None),
                "shadow_method": getattr(mat, "shadow_method", None),
                "use_transparent_shadow": getattr(mat, "use_transparent_shadow", None),
                "alpha_threshold": getattr(mat, "alpha_threshold", None),
                "use_nodes": mat.use_nodes,
                "node_count": len(mat.node_tree.nodes) if mat.use_nodes and mat.node_tree else 0,
                "has_transparent_bsdf": bool(
                    mat.use_nodes
                    and mat.node_tree
                    and any(n.bl_idname == "ShaderNodeBsdfTransparent" for n in mat.node_tree.nodes)
                ),
            }
        )
    write_json(
        out_json,
        {
            "filepath": bpy.data.filepath,
            "material_count": len(rows),
            "materials": rows,
            "note": "Read-only audit; this script does not save the blend file.",
        },
    )
    strict_pass(f"Audited {len(rows)} materials without saving")


guarded(main)
