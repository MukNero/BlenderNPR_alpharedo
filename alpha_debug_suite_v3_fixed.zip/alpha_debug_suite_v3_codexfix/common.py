from __future__ import annotations

import json
import os
import sys
import traceback
from pathlib import Path


def args_after_doubledash() -> list[str]:
    return sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_json(path: str | Path, data) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def strict_fail(message: str, code: int = 23) -> None:
    print(f"STRICT_FAIL: {message}", flush=True)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(code)


def strict_pass(message: str = "PASS") -> None:
    print(f"STRICT_PASS: {message}", flush=True)


def guarded(main):
    try:
        main()
    except BaseException:
        traceback.print_exc()
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(24)


def set_eevee(scene) -> str:
    errors = []
    for engine in ("BLENDER_EEVEE", "BLENDER_EEVEE_NEXT"):
        try:
            scene.render.engine = engine
            return engine
        except Exception as exc:
            errors.append(f"{engine}: {exc}")
    strict_fail("Unable to select Eevee: " + " | ".join(errors))
    raise AssertionError


def look_at(obj, target):
    obj.rotation_euler = (target - obj.location).to_track_quat("-Z", "Y").to_euler()
