from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy
from common import args_after_doubledash, guarded, strict_pass, write_json


def main() -> None:
    args = args_after_doubledash()
    out_dir = Path(args[0]) if args else Path.cwd()
    out_dir.mkdir(parents=True, exist_ok=True)
    blend_path = out_dir / "alpha_persistence.blend"
    manifest_path = out_dir / "alpha_persistence_expected.json"

    expected = []
    thresholds = {"OPAQUE": 0.11, "CLIP": 0.37, "HASHED": 0.63, "BLEND": 0.89}
    for surface in ("OPAQUE", "CLIP", "HASHED", "BLEND"):
        for shadow in ("NONE", "OPAQUE", "CLIP", "HASHED"):
            mat = bpy.data.materials.new(f"PERSIST_{surface}_{shadow}")
            mat.use_nodes = True
            mat.use_fake_user = True
            mat.blend_method = surface
            if hasattr(mat, "shadow_method"):
                mat.shadow_method = shadow
            mat.alpha_threshold = thresholds[surface]
            expected.append(
                {
                    "name": mat.name,
                    "blend_method": surface,
                    "shadow_method": shadow,
                    "alpha_threshold": thresholds[surface],
                }
            )

    write_json(manifest_path, expected)
    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
    strict_pass(f"Created persistence fixture: {blend_path}")


guarded(main)
