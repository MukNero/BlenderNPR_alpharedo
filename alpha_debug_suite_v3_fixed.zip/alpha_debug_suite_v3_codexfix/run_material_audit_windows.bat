@echo off
setlocal
if "%~2"=="" (
  echo Usage: run_material_audit_windows.bat ^<blender.exe^> ^<COPY-of-project.blend^> [output.json]
  exit /b 2
)
set "BLENDER=%~f1"
set "BLEND=%~f2"
if "%~3"=="" (set "OUT=%~dp0material_audit.json") else (set "OUT=%~f3")
"%BLENDER%" "%BLEND%" -b --python "%~dp006_material_audit_readonly.py" -- "%OUT%"
exit /b %ERRORLEVEL%
