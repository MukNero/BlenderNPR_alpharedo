param(
    [Parameter(Mandatory = $true)]
    [string]$BatchPath,

    [Parameter(Mandatory = $true)]
    [string]$BlenderPath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [Parameter(Mandatory = $true)]
    [string]$ConsoleLog,

    [Parameter(Mandatory = $true)]
    [string]$ErrorLog,

    [Parameter(Mandatory = $true)]
    [string]$StatusPath
)

$ErrorActionPreference = "Stop"

$batch = [System.IO.Path]::GetFullPath($BatchPath)
$blender = [System.IO.Path]::GetFullPath($BlenderPath)
$output = [System.IO.Path]::GetFullPath($OutputPath)
$stdout = [System.IO.Path]::GetFullPath($ConsoleLog)
$stderr = [System.IO.Path]::GetFullPath($ErrorLog)
$status = [System.IO.Path]::GetFullPath($StatusPath)

[System.IO.Directory]::CreateDirectory($output) | Out-Null
[System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($stdout)) | Out-Null

$command = "`"$batch`" `"$blender`" `"$output`""
$process = Start-Process `
    -FilePath "cmd.exe" `
    -ArgumentList @("/d", "/s", "/c", "`"$command`"") `
    -WindowStyle Hidden `
    -Wait `
    -PassThru `
    -RedirectStandardOutput $stdout `
    -RedirectStandardError $stderr

$lines = @(
    "exit_code=$($process.ExitCode)"
    "finished=$((Get-Date).ToString('O'))"
    "batch=$batch"
    "blender=$blender"
    "output=$output"
    "stdout=$stdout"
    "stderr=$stderr"
)
[System.IO.File]::WriteAllText($status, ($lines -join [Environment]::NewLine))
exit $process.ExitCode
